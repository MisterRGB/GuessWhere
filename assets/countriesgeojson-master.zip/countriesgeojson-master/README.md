# Countries GEOJSON

List of countries as GeoJSON. Slightly modified version of files found here (https://github.com/johan/world.geo.json)

